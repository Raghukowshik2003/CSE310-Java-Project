package progJava;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class OrderModule extends JFrame {
    
	private static int orderIdCounter = 1;
    private String getCurrentDateAsString() {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedDate = myDateObj.format(myFormatObj);
        return formattedDate;
    }
    public OrderModule() {
        setTitle("Order Now");
        setSize(400,450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         
        
        

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(panel);

        JLabel membersLabel = new JLabel("Number of Members:");
        JTextField membersField = new JTextField();
        panel.add(membersLabel);
        panel.add(membersField);

        JLabel cuisineLabel = new JLabel("Type of Cuisine:");
        JComboBox<String> cuisineDropdown = new JComboBox<>(new String[]{"IndianVeg Cuisine", "Chinese Cuisine", "Italian Cuisine", "Mexican Cuisine","IndianMixed Cuisine"});
        panel.add(cuisineLabel);
        panel.add(cuisineDropdown);

        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField();
        panel.add(addressLabel);
        panel.add(addressField);
        
        JLabel paymentLabel = new JLabel("Payment Method:");
        JComboBox<String> paymentDropdown = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "Net Banking", "UPI"});
        panel.add(paymentLabel);
        panel.add(paymentDropdown);
        
        JLabel dateLabel = new JLabel("Date:");
        JTextField dateField = new JTextField(getCurrentDateAsString());
        dateField.setEditable(false); 
        panel.add(dateLabel);
        panel.add(dateField);
        
        
        
        JButton orderNowButton = new JButton("Order Now");
        orderNowButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        orderNowButton.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        	    int numMembers = Integer.parseInt(membersField.getText());
        	    String cuisineType = (String) cuisineDropdown.getSelectedItem();
        	    String address = addressField.getText();
        	    
        	    // Calculate the amount based on the cuisine type
        	    double amount = 0;
        	    switch (cuisineType) {
        	        case "Chinese Cuisine":
        	            amount = numMembers * 1800;
        	            break;
        	        case "Italian Cuisine":
        	            amount = numMembers * 2130;
        	            break;
        	        case "Mexican Cuisine":
        	            amount = numMembers * 1500;
        	            break;
        	        case "IndianVeg Cuisine":
        	            amount = numMembers * 900;
        	            break;
        	        case "IndianMixed Cuisine":
        	            amount = numMembers * 820;
        	            break;
        	    }
        	    
        	    // Open the payment module
        	    PaymentModule paymentModule = new PaymentModule(amount);
        	    paymentModule.setVisible(true);
        	    
        	    // Get the selected payment method from the payment module
        	    String paymentMethod = paymentModule.getSelectedPaymentMethod();
        	    
        	    // Generate a new order id
        	    
        	    int orderId = orderIdCounter++;
        	    
        	    Order order = new Order(orderId, numMembers, cuisineType, address, amount, paymentMethod, getCurrentDateAsString());

        	    // Save the order to a text file
        	    try {
        	        FileWriter writer = new FileWriter("C:\\Users\\Mohana\\eclipse-workspace\\orders.txt", true);
        	        writer.write(order.toString());
        	        writer.close();
        	    } catch (IOException ex) {
        	        ex.printStackTrace();
        	    }
        	    
        	    // Add the order to the order history
        	    
        	}
        });
        panel.add(Box.createVerticalStrut(20));
        panel.add(orderNowButton);
    }


public static void main(String[] args) {
    JFrame frame = new JFrame();
    frame.getContentPane().add(new OrderModule());
    frame.pack();
    frame.setVisible(true);
}
}
            
   


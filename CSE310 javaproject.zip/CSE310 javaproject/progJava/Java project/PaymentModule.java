package progJava;

import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

public class PaymentModule extends JFrame {
    private JLabel amountLabel;
    private JComboBox<String> paymentMethodDropdown;
    private double totalAmount;

    public PaymentModule(double amount) {
        setTitle("Payment");
        setSize(400, 400);
        setLayout(new BorderLayout());

        JPanel amountPanel = new JPanel();
        amountLabel = new JLabel();
        amountLabel.setFont(new Font("Arial", Font.BOLD, 20));
        amountPanel.add(amountLabel);
        add(amountPanel, BorderLayout.CENTER);

        JPanel paymentMethodPanel = new JPanel();
        JLabel paymentMethodLabel = new JLabel("Payment Method:");
        paymentMethodDropdown = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "Net Banking", "UPI"});
        paymentMethodPanel.add(paymentMethodLabel);
        paymentMethodPanel.add(paymentMethodDropdown);
        add(paymentMethodPanel, BorderLayout.NORTH);

        JButton payNowButton = new JButton("Pay Now");
        payNowButton.setPreferredSize(new Dimension(150, 50));
        payNowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String paymentMethod = getSelectedPaymentMethod();
                if (paymentMethod == null) {
                    JOptionPane.showMessageDialog(PaymentModule.this, "Please select a payment method!");
                    return;
                }
                JOptionPane.showMessageDialog(PaymentModule.this, "Payment Successful!");
                dispose();

               
            }
        });
        add(payNowButton, BorderLayout.SOUTH);

        totalAmount = amount;
        amountLabel.setText("Total Amount: Rs" + totalAmount);

        setVisible(true);
    }

    public String getSelectedPaymentMethod() {
        String paymentMethod = (String) paymentMethodDropdown.getSelectedItem();
        if (paymentMethod.equals("")) {
            return null;
        }
        return paymentMethod;
    }

    
}



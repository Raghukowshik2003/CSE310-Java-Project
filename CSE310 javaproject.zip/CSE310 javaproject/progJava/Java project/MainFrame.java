package progJava;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.awt.event.ActionListener;

import javax.swing.border.Border;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class MainFrame extends JFrame {
    private MenuModule menuModule;
    private CuisineMenu cuisinemenu;
    private CompanyDetails companyDetails;

    
    public MainFrame() {
        setTitle("Catering Management System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // create a custom JPanel with a background image
        ImagePanel contentPane = new ImagePanel(new ImageIcon("dishh.jpg").getImage());
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        setVisible(true);
        
        

        /// LOGIN module......
        Login login = new Login();
        
        login.setVisible(true);
        login.setBounds(400, 200, 500, 300);
        
        // add a listener to the login screen's sign-in button
        login.b1.addActionListener(e -> {
            boolean matched = false;
            String uname = login.t1.getText().toString();
            String pwd = login.t2.getText().toString();

            try {
                FileReader fr = new FileReader("login.txt");
                BufferedReader br = new BufferedReader(fr);
                String line;
                while((line=br.readLine())!=null){
                    if(line.equals(uname+"\t"+pwd)) {
                        matched = true;
                        break;
                    }
                }
                fr.close();
            } catch(Exception ex) {}

            if(matched) {
                // hide the login screen and show the main frame
                login.dispose();
                setVisible(true);
            } else {
                login.l2.setText("Invalid username or password");
            }
        });

        
        
        JPanel buttonPanel = new JPanel(new GridBagLayout()); // use GridBagLayout to center the buttons
        buttonPanel.setOpaque(false); // make the button panel transparent

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // add some spacing between buttons
        
         /// view menubutton
        
        JButton viewMenuButton = new JButton("View Menu");
        
        viewMenuButton.setPreferredSize(new Dimension(200, 70)); // increase button size
        viewMenuButton.setFont(new Font("Verdana", Font.BOLD, 18));
        viewMenuButton.setUI(new RoundButtonUI());
        viewMenuButton.setOpaque(false);
        viewMenuButton.setBorderPainted(false);
        viewMenuButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	viewMenuButton.setBackground(new Color(173, 216, 230));
                viewMenuButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
                viewMenuButton.setPreferredSize(new Dimension(220, 90));
                viewMenuButton.revalidate();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                viewMenuButton.setBackground(Color.WHITE);
                viewMenuButton.setFont(new Font("Verdana", Font.BOLD, 18));
                viewMenuButton.setPreferredSize(new Dimension(200, 70));
                viewMenuButton.revalidate();
            }
            
        });
        viewMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CuisineMenu cuisineMenu = new CuisineMenu();
                cuisineMenu.setResizable(false);
                cuisineMenu.setVisible(true);
                
            }
        });
       
            gbc.gridx = 0;
            gbc.gridy = 0;
            buttonPanel.add(viewMenuButton, gbc);

            JButton orderButton = new JButton("Order Now");
            orderButton.setPreferredSize(new Dimension(200, 70)); // increase button size
            orderButton.setFont(new Font("Verdana", Font.BOLD, 18));
            orderButton.setUI(new RoundButtonUI());
            orderButton.setOpaque(false);
            orderButton.setBorderPainted(false);
            orderButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                	orderButton.setBackground(new Color(173, 216, 230));
                	orderButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
                	orderButton.setPreferredSize(new Dimension(220, 90));
                	orderButton.revalidate();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                	orderButton.setBackground(Color.WHITE);
                	orderButton.setFont(new Font("Verdana", Font.BOLD, 18));
                	orderButton.setPreferredSize(new Dimension(200, 70));
                	orderButton.revalidate();
                }
            });
            orderButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    OrderModule orderModule = new OrderModule();
                    orderModule.setVisible(true);
                }
            });
            gbc.gridx = 4;
            gbc.gridy = 0;
            buttonPanel.add(orderButton, gbc);

            JButton feedbackButton = new JButton("Feedback");
            feedbackButton.setPreferredSize(new Dimension(200, 70)); // increase button size
            feedbackButton.setFont(new Font("Verdana", Font.BOLD, 18));
            feedbackButton.setUI(new RoundButtonUI());
            feedbackButton.setOpaque(false);
            feedbackButton.setBorderPainted(false);
            feedbackButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                	feedbackButton.setBackground(new Color(173, 216, 230));
                	feedbackButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
                	feedbackButton.setPreferredSize(new Dimension(220, 90));
                	feedbackButton.revalidate();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                	feedbackButton.setBackground(Color.WHITE);
                	feedbackButton.setFont(new Font("Verdana", Font.BOLD, 18));
                	feedbackButton.setPreferredSize(new Dimension(200, 70));
                	feedbackButton.revalidate();
                }
            });
            feedbackButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FeedbackModule feedbackModule = new FeedbackModule();
                    feedbackModule.setVisible(true);
                }
            });
            gbc.gridx = 1;
            gbc.gridy = 3;
            buttonPanel.add(feedbackButton, gbc);

            JButton customerSupportButton = new JButton("Customer Support");
            customerSupportButton.setPreferredSize(new Dimension(200, 70)); // increase button size
            customerSupportButton.setFont(new Font("Verdana", Font.BOLD, 18));
            customerSupportButton.setUI(new RoundButtonUI());
            customerSupportButton.setOpaque(false);
            customerSupportButton.setBorderPainted(false);
            customerSupportButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    customerSupportButton.setBackground(new Color(173, 216, 230));
                    customerSupportButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
                    customerSupportButton.setPreferredSize(new Dimension(220, 90));
                    customerSupportButton.revalidate();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    customerSupportButton.setBackground(Color.WHITE);
                    customerSupportButton.setFont(new Font("Verdana", Font.BOLD, 18));
                    customerSupportButton.setPreferredSize(new Dimension(200, 70));
                    customerSupportButton.revalidate();
                }
            });
            customerSupportButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ComplaintForm complaints = new ComplaintForm();
                    complaints.setVisible(true);
                }
            });
            gbc.gridx = 4;
            gbc.gridy = 1;
            buttonPanel.add(customerSupportButton, gbc);
            
            JButton displayCompanyDetailsButton = new JButton("Company Details");
            displayCompanyDetailsButton.setPreferredSize(new Dimension(200, 70)); // increase button size
            displayCompanyDetailsButton.setFont(new Font("Verdana", Font.BOLD, 18));
            displayCompanyDetailsButton.setUI(new RoundButtonUI());
            displayCompanyDetailsButton.setOpaque(false);
            displayCompanyDetailsButton.setBorderPainted(false);
            displayCompanyDetailsButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                	displayCompanyDetailsButton.setBackground(new Color(173, 216, 230));
                	displayCompanyDetailsButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
                	displayCompanyDetailsButton.setPreferredSize(new Dimension(220, 90));
                	displayCompanyDetailsButton.revalidate();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                	displayCompanyDetailsButton.setBackground(Color.WHITE);
                	displayCompanyDetailsButton.setFont(new Font("Verdana", Font.BOLD, 18));
                	displayCompanyDetailsButton.setPreferredSize(new Dimension(200, 70));
                	displayCompanyDetailsButton.revalidate();
                }
            });
            displayCompanyDetailsButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (companyDetails == null) {
                        companyDetails = new CompanyDetails();
                        companyDetails.addWindowListener(new WindowAdapter() {
                            public void windowClosing(WindowEvent e) {
                                companyDetails.setVisible(false); // set frame to invisible instead of disposing
                            }
                        });
                    }
                    companyDetails.setVisible(true);
                }
            });

            gbc.gridx = 0;
            gbc.gridy = 1;
            buttonPanel.add(displayCompanyDetailsButton, gbc);

            add(buttonPanel, BorderLayout.CENTER);
            setVisible(true);
            setLocationRelativeTo(null); // center the window on the screen
        }

        public static void main(String[] args) {
            MainFrame frame = new MainFrame();
            frame.setVisible(false);
            
        }
    }

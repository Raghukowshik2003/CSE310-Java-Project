package progJava;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;

public class FeedbackModule extends JFrame {
    private int rating;
    private JTextField nameField;
    private JFormattedTextField phoneField;
    private JTextField feedbackField;

    public FeedbackModule() {
        setTitle("Feedback");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(panel);

        JLabel nameLabel = new JLabel("Name:");
        panel.add(nameLabel);

        nameField = new JTextField();
        panel.add(nameField);

        JLabel phoneLabel = new JLabel("Phone:");
        panel.add(phoneLabel);

        try {
            MaskFormatter phoneFormatter = new MaskFormatter(" ##########");
            phoneFormatter.setValidCharacters("0123456789");
            phoneField = new JFormattedTextField(phoneFormatter);
            phoneField.setColumns(10);
            panel.add(phoneField);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        JLabel ratingLabel = new JLabel("Rate our service:");
        panel.add(ratingLabel);

        JPanel starPanel = new JPanel();
        for (int i = 1; i <= 5; i++) {
            JButton starButton = new JButton(String.valueOf(i));
            starButton.setPreferredSize(new Dimension(50, 50));
            starButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    rating = Integer.parseInt(e.getActionCommand());
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Click on Submit to give the Rating");
                }
            });
            starPanel.add(starButton);
        }
        panel.add(starPanel);

        JLabel feedbackLabel = new JLabel("Feedback:");
        panel.add(feedbackLabel);

        feedbackField = new JTextField();
        panel.add(feedbackField);

        JButton submitButton = new JButton("Submit");
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String phone = phoneField.getText().replaceAll("\\D", ""); // remove non-digit characters
                String feedback = feedbackField.getText();
                if (name.isEmpty() || phone.isEmpty() || feedback.isEmpty()) {
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Please enter all fields!");
                    return;
                }
                if (phone.length() != 10) {
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Please enter a 10-digit phone number.");
                    return;
                }
                JTextArea feedbackArea = new JTextArea();
                feedbackArea.setLineWrap(true);
                feedbackArea.setWrapStyleWord(true);
                JScrollPane feedbackScrollPane = new JScrollPane(feedbackArea);
                panel.add(feedbackScrollPane);

                if (feedback.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Please enter your feedback.");
                    return;
                }
                try {
                    FileWriter fileWriter = new FileWriter("C:\\Users\\Mohana\\eclipse-workspace\\feedback.txt", true);
                    BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                    bufferedWriter.write("Customer Name: " + name + "\n" + "Phone Number: " + phone + "\n" + "Rating: " + rating + "\n" + "Feedback: " + feedback +"\n"+
                            "------------------------ \n");
                    bufferedWriter.close();
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Thanks for your feedback! Your rating is: " + rating);
                    dispose();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(FeedbackModule.this, "Error writing to file: " + ex.getMessage());
                } 
            }
        });
        panel.add(Box.createVerticalStrut(20));
        panel.add(submitButton);

        setVisible(true);
    }
}

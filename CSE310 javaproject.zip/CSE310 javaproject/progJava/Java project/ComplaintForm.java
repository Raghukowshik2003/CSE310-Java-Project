package progJava;

import java.awt.Dimension;

import javax.swing.*;

import javax.swing.*;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ComplaintForm extends JFrame {
    private static final long serialVersionUID = 1L;

    public ComplaintForm() {
        setTitle("Complaint Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 400);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(176, 224, 230));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);

        JLabel nameLabel = new JLabel("Customer Name:");
        nameLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        panel.add(nameLabel, c);

        c.gridx++;
        JTextField nameField = new JTextField(20);
        nameField.setPreferredSize(new Dimension(190, 25));
        panel.add(nameField, c);

        c.gridx = 0;
        c.gridy++;
        JLabel phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        panel.add(phoneLabel, c);

        c.gridx++;
        JTextField phoneField = new JTextField(20);
        phoneField.setPreferredSize(new Dimension(190, 25));
        panel.add(phoneField, c);

        c.gridx = 0;
        c.gridy++;
        JLabel label = new JLabel("Select the complaint type from the below drop down");
        label.setFont(new Font("Verdana", Font.PLAIN, 16));
        panel.add(label, c);

        c.gridy++;
        JComboBox<String> dropdown = new JComboBox<>(new String[] { "FoodItem Issue", "Food Quantity", "Food Quality","Payment Issue" });
        dropdown.setPreferredSize(new Dimension(190, 25));
        panel.add(dropdown, c);

        c.gridy++;
        c.anchor = GridBagConstraints.WEST;
        JCheckBox checkBox = new JCheckBox("Notify me when the issue is resolved");
        checkBox.setFont(new Font("Verdana", Font.PLAIN, 14));
        panel.add(checkBox, c);

        c.gridy++;
        JButton submitButton = new JButton("Submit");
        submitButton.setPreferredSize(new Dimension(100, 30));
        submitButton.setFont(new Font("Verdana", Font.BOLD, 14));
        submitButton.setBorder(BorderFactory.createRaisedBevelBorder());
        panel.add(submitButton, c);
        
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String phone = phoneField.getText();
                String complaint = dropdown.getSelectedItem().toString();
                boolean notify = checkBox.isSelected();
                
                try {
                    FileWriter writer = new FileWriter("C:\\\\Users\\\\Mohana\\\\eclipse-workspace\\\\complaints.txt", true);
                    writer.write("Customer name:" +name +"\n"+ "Phone Number:"+ phone + "\n"+ "Complaint type:" + complaint + "\n" + notify + "\n"+"------------------------ \n");
                    writer.close();
                    
                    JOptionPane.showMessageDialog(null, "Complaint submitted successfully!");
                    
                    dispose(); // close the window after submission
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error writing to file!");
                }
            }
        });

        setContentPane(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new ComplaintForm();
    }
}









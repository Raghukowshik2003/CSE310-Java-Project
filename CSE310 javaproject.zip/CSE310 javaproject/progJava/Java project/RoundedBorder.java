package progJava;

import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;

import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
class RoundButtonUI extends BasicButtonUI {
    @Override
    public void paint(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        ButtonModel model = b.getModel();
         
        
        Graphics2D g2 = (Graphics2D) g;;
        // draw the button background
        g.setColor(b.getBackground());
        g.fillOval(0, 0, b.getWidth() - 1, b.getHeight() - 1);

        // draw the button border
        int arcWidth = 50; // set the horizontal diameter of the arcs at the four corners of the rectangle
        int arcHeight = 50;
        g.setColor(b.getForeground());
        g.drawOval(0, 0, b.getWidth() - 1, b.getHeight() - 1);
        
        
        // draw the button label
        FontMetrics fm = g2.getFontMetrics();
        int x = (b.getWidth() - fm.stringWidth(b.getText())) / 2;
        int y = (b.getHeight() + fm.getAscent()) / 2;
        g2.drawString(b.getText(), x, y);
    }
}
package progJava;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Date;

import java.util.Date;

public class Order {
	private static int currentOrderId = 0;
    private int orderId;
    private int numMembers;
    private String cuisineType;
    private String address;
    private double amount;
    private String paymentMethod;
    private String orderDate;

    public Order(int orderId, int numMembers, String cuisineType, String address, double amount, String paymentMethod, String orderDate) {
    	this.orderId = currentOrderId++;
    	this.orderId = orderId;
        this.numMembers = numMembers;
        this.cuisineType = cuisineType;
        this.address = address;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.orderDate = orderDate;
    }

    public int getOrderId() {
    	orderId++;
        return orderId;
    }

    public int getNumMembers() {
        return numMembers;
    }

    public String getCuisineType() {
        return cuisineType;
    }

    public String getAddress() {
        return address;
    }

    public double getAmount() {
        return amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getOrderDate() {
        return orderDate;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + "\n" +
               "Number of Members: " + numMembers + "\n" +
               "Type of Cuisine: " + cuisineType + "\n" +
               "Address: " + address + "\n" +
               "Amount: " + amount + "\n" +
               "Payment Method: " + paymentMethod + "\n" +
               "Date: " + orderDate + "\n" +
               "------------------------\n";
    }
}


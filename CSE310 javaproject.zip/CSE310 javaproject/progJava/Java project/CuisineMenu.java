package progJava;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class CuisineMenu extends JFrame {

    // Create a JComboBox for cuisine types
    JComboBox<String> cuisineComboBox;
    private List<String> foodItems = new ArrayList<>();
    
    // Define a string array for the cuisine types
    String[] cuisineTypes = {"Chinese", "Italian", "Mexican", "IndianVeg", "IndianMixed"};

    // Other components in the frame
    JButton submitButton = new JButton("Submit");

    public CuisineMenu() {
        // Set the frame properties
        setTitle("Cuisine Selector");
        setSize(500, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImagePanel contentPane = new ImagePanel(new ImageIcon("cuisinetype.jpg").getImage());
        setContentPane(contentPane);
        
        // Adding color to the text below
        JLabel label = new JLabel("Select Cuisine Type:");
        label.setFont(new Font("Times New Roman", Font.ITALIC, 29));
        label.setForeground(Color.BLACK);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        label.setBackground(Color.YELLOW);
        label.setOpaque(true);

        // Modifying cuisineComboBox
        Font font = new Font("Arial", Font.PLAIN, 16);
        cuisineComboBox = new JComboBox<>(cuisineTypes);
        cuisineComboBox.setFont(font);
        cuisineComboBox.setBackground(new Color(124, 124, 224));
        cuisineComboBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        // Set the maximum size for the dropdown
        cuisineComboBox.setMaximumSize(new Dimension(250, 20));

        submitButton.setFont(font);
        submitButton.setBackground(new Color(124, 124, 224));
        submitButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        // Set the maximum size for the button
        submitButton.setMaximumSize(new Dimension(230, 50));
        submitButton.setFont(new Font("Arial", Font.ITALIC, 22));

        // Use a BoxLayout to center the components vertically
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        add(Box.createVerticalGlue());
        add(label);
        label.setAlignmentX(CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 20)));
        add(cuisineComboBox);
        cuisineComboBox.setAlignmentX(CENTER_ALIGNMENT);
        add(Box.createRigidArea(new Dimension(0, 30)));
        add(submitButton);
        submitButton.setAlignmentX(getContentPane().CENTER_ALIGNMENT);

        // Attach action listener to the submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCuisine = (String) cuisineComboBox.getSelectedItem();
                getFoodItems(selectedCuisine);
                
                if (!foodItems.isEmpty()) {
                	JPanel foodItemsPanel = new JPanel(new GridLayout(foodItems.size(), 1));
                	
                	// Set the font size for the labels
                    Font font = new Font("Arial", Font.PLAIN, 24);
                    
                    // Add labels to the panel
                    for (int i = 0; i < foodItems.size(); i++) {
                        String foodItem = (String) foodItems.get(i);
                        String cuisine = getCuisine(foodItem);
                        String imagePath = cuisine + "/" + foodItem + ".jpg";
                        ImageIcon imageIcon = new ImageIcon(imagePath);
                        Image image = imageIcon.getImage();
                        Image scaledImage = image.getScaledInstance(190, 190, Image.SCALE_SMOOTH);
                        ImageIcon scaledIcon = new ImageIcon(scaledImage);
                        JLabel imageLabel = new JLabel(scaledIcon);
                        JLabel nameLabel = new JLabel(foodItem);
                        nameLabel.setFont(new Font("Arial Black", Font.ITALIC, 24));
                        nameLabel.setForeground(Color.BLACK);
                        JPanel foodItemPanel = new JPanel(new BorderLayout());
                        foodItemPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1)); // add line border
                        foodItemPanel.add(imageLabel, BorderLayout.EAST);
                        foodItemPanel.add(nameLabel, BorderLayout.WEST);
                        foodItemsPanel.add(foodItemPanel);
                    }
                	
                	 // create a new panel to hold the food items panel
                    

                    // create a new frame and add the panel to it
                    JFrame foodFrame = new JFrame(selectedCuisine + " Food Items");
                    foodFrame.setSize(850, 800);
                    foodFrame.setResizable(true); // disable resize
                    foodFrame.setLocationRelativeTo(null);
                    foodFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    foodFrame.getContentPane().add(foodItemsPanel);
                   
                    foodFrame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "No food items found for the selected cuisine.");
                }
            }
        });
    }
    public static String getCuisine(String foodItem) {
        if (foodItem.contains("Italianpizza") || foodItem.contains("Pasta") || foodItem.contains("spaghetti")|| foodItem.contains("Tiramisu")|| foodItem.contains("Minestrone soup")|| foodItem.contains("Lasagna")|| foodItem.contains("Focaccia") || foodItem.contains("Cannoli")){
            return "Italiancuisine";
        } else if (foodItem.contains("Burritos") || foodItem.contains("Churros") || foodItem.contains("Enchiladas") || foodItem.contains("Fajitas") || foodItem.contains("Flan") || foodItem.contains("Quesadillas") || foodItem.contains("Tacos al Pastor") || foodItem.contains("Tres Leches Cake")){
            return "Mexicancuisine";
        } else if (foodItem.contains("Alu Tikki Chaat") || foodItem.contains("Butter Naan") || foodItem.contains("Channa Daal") || foodItem.contains("Gobi Manchurian") || foodItem.contains("Mixed Pakoda") || foodItem.contains("Mushroom Matar Makhani") || foodItem.contains("Paneer Butter Masala") || foodItem.contains("Panipuri") || foodItem.contains("VegBiryani") || foodItem.contains("Vegkabab")) {
            return "IndianVegcuisine";
        } else if (foodItem.contains("Chicken 65") || foodItem.contains("Chicken Curry")|| foodItem.contains("Chicken Dum Biryani") || foodItem.contains("Chicken fry") || foodItem.contains("Curd Rice")|| foodItem.contains("Gongura Pachadi (Sorrel Leaves Chutney)") || foodItem.contains("Mirchi Bajji (Chilli Fritters)") || foodItem.contains("Payasam (Sweet Pudding)") || foodItem.contains("Plain rice") || foodItem.contains("Pulihora (Tamarind Rice)") || foodItem.contains("Sambar")) {
            return "IndianMixedcuisine";
        } else if (foodItem.contains("Barbecue pork") || foodItem.contains("chickenfriedrice") || foodItem.contains("ChineseDumplings") || foodItem.contains("ChowMein")|| foodItem.contains("Egg Tart") || foodItem.contains("KungPaoChicken") || foodItem.contains("Mapo tofu") || foodItem.contains("Mooncake") || foodItem.contains("Steamed fish") || foodItem.contains("Sweet and SourPork")){
            return "Chinesecuisine"; 
        } else {
            return "";
        }
    }
     // This method returns the food items for the selected cuisine.
        private void getFoodItems(String cuisine) {
        	foodItems.clear(); // clear the list before adding new items
        switch (cuisine) {
        case "Chinese":
        foodItems.add("chickenfriedrice");	
        foodItems.add("ChineseDumplings");
        foodItems.add("KungPaoChicken");
        foodItems.add("ChowMein");
        foodItems.add("Egg Tart");
        foodItems.add("KungPaoChicken");
        foodItems.add("Mapo tofu");
        foodItems.add("Mooncake");
        foodItems.add("Steamed fish");
        foodItems.add("Sweet and SourPork");
        break;
        case "Italian":
        foodItems.add("Italianpizza");
        foodItems.add("Pasta");
        foodItems.add("spaghetti");
        foodItems.add("Tiramisu");
        foodItems.add("Minestrone soup");
        foodItems.add("Lasagna");
        foodItems.add("Focaccia");
        foodItems.add("Cannoli");
        break;
        case "Mexican":
        foodItems.add("Burritos");
        foodItems.add("Churros");
        foodItems.add("Enchiladas");
        foodItems.add("Fajitas");
        foodItems.add("Flan");
        foodItems.add("Quesadillas");
        foodItems.add("Tacos al Pastor");
        foodItems.add("Tres Leches Cake");
        break;
        case "IndianVeg":
        foodItems.add("Alu Tikki Chaat");
        foodItems.add("Butter Naan");
        foodItems.add("Channa Daal");
        foodItems.add("Gobi Manchurian");
        foodItems.add("Mixed Pakoda");
        foodItems.add("Mushroom Matar Makhani");
        foodItems.add("Paneer Butter Masala");
        foodItems.add("Panipuri");
        foodItems.add("VegBiryani");
        foodItems.add("Vegkabab");
        break;
        case "IndianMixed":
        foodItems.add("Chicken 65");
        foodItems.add("Chicken Curry");
        foodItems.add("Chicken Dum Biryani");
        foodItems.add("Chicken fry");
        foodItems.add("Curd Rice");
        foodItems.add("Gongura Pachadi (Sorrel Leaves Chutney)");
        foodItems.add("Mirchi Bajji (Chilli Fritters)");
        foodItems.add("Payasam (Sweet Pudding)");
        foodItems.add("Plain rice");
        foodItems.add("Pulihora (Tamarind Rice)");
        foodItems.add("Sambar");
        break;
        }
        }

        public static void main(String[] args) {
        CuisineMenu cuisinemenu = new CuisineMenu();
        cuisinemenu.setSize(600,600);
        cuisinemenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cuisinemenu.setVisible(true);
        }
}
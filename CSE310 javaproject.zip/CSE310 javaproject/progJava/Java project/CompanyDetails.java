package progJava;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import javax.swing.*;
import java.awt.*;

import javax.swing.*;
import java.awt.*;

public class CompanyDetails extends JFrame {

    private static final long serialVersionUID = 1L;

    public CompanyDetails() {
        setTitle("Company Details");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 400);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(176, 224, 230));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);

        JLabel companyLabel = new JLabel("Company Name: ~.Minerva Catering Services.~");
        companyLabel.setFont(new Font("Verdana", Font.BOLD, 16));
        panel.add(companyLabel, c);

        ImageIcon imageicon = new ImageIcon("CHEFcd.jpg");
        Image image = imageicon.getImage();
        Image scaledImage = image.getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
        JLabel imageLabel = new JLabel(scaledImageIcon);
        c.gridy++;
        panel.add(imageLabel, c);

        c.gridy++;
        JLabel addressLabel = new JLabel("<html>Address: <br>Jagganaickpur,Vishnalayam-Street<br>City-Kakinada(Urban)<br>PinCode:533002<br>State:- AndhraPradesh<br>Country-India</html>");
        addressLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        panel.add(addressLabel, c);

        c.gridy++;
        JLabel contactLabel = new JLabel("Contact: +1 234 567 8901");
        contactLabel.setFont(new Font("Verdana", Font.PLAIN, 14));
        panel.add(contactLabel, c);

        setContentPane(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new CompanyDetails();
    }
}





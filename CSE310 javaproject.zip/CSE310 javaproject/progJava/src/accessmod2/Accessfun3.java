package accessmod2;

import accessmod1.Accessfun1;

public class Accessfun3 extends Accessfun1 {
	public static void main(String[] args) {
		Accessfun3 fun = new Accessfun3();
		System.out.println("Different package but a subclass");
		System.out.println(fun.grade);
		System.out.println(fun.marks);
		System.out.println(fun.getMarks());
	}

}

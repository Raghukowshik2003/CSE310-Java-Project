package progJava;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class SignUp extends JFrame {
    JTextField t1,t2;
    JButton b1;
    SignUp() {
        setLayout(null);
        
        JLabel usernameLabel = new JLabel("Enter Username:");
        JLabel passwordLabel = new JLabel("Enter Password:");
        usernameLabel.setBounds(20,20,100,30);
        passwordLabel.setBounds(20,60,100,30);
        add(usernameLabel);
        add(passwordLabel);
        
        
        t1 = new JTextField(100);
        t2 = new JPasswordField(100);
        b1 = new JButton("Submit");
        t1.setBounds(150,20,80,30);
        t2.setBounds(150,60,80,30);
        b1.setBounds(100,100,80,30);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    FileWriter fw = new FileWriter("login.txt",true);
                    fw.write(t1.getText()+"\t"+t2.getText()+"\n");
                    fw.close();
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f,"Registration Completed");
                    dispose();
                } catch (Exception e) {}
            }
        });
        add(t1);
        add(t2);
        add(b1);
    }
}

interface LoginListener {
    void onLogin();
}

class Login extends JFrame{
    JTextField t1, t2;
    JButton b1,b2;
    JLabel l1,l2;
    private LoginListener loginListener;
    
    Login(){
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel imageLabel = new JLabel();
        ImageIcon image = new ImageIcon("C:\\\\Users\\\\Mohana\\\\Downloads\\\\_17eb81e5-42db-402e-9bb2-c8c8c96310fd.jpeg");
        Image scaledImage = image.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        image = new ImageIcon(scaledImage);
        imageLabel.setIcon(image);
        imageLabel.setBounds(280, 10, 250, 250);
        add(imageLabel);
        
        l1= new JLabel("Login");
        l1.setFont(new Font("Times New Roman",Font.BOLD,30));
        l1.setForeground(Color.BLUE);
        l1.setBounds(100,10,300,30);
        add(l1);
        
        JLabel usernameLabel = new JLabel("Enter Username:");
        JLabel passwordLabel = new JLabel("Enter Password:");
        usernameLabel.setBounds(20,20,100,100);
        passwordLabel.setBounds(20,60,100,100);
        add(usernameLabel);
        add(passwordLabel);
        
        t1 = new JTextField(80);
        t2 = new JPasswordField(80);
        b1= new JButton("SignIn");
        b2= new JButton("SignUp");
        
        t1.setBounds(150,60,120,30);
        t2.setBounds(150,100,120,30);
        b1.setBounds(120,140,80,30);
        b2.setBounds(120,170,80,30);
        
        l2= new JLabel("");
        l2.setBounds(250,80,300,30);
        add(l2);
        
        add(t1);
        add(t2);
        add(b1);
        add(b2);
        
        b1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae) {
                boolean matched = false;
                String uname = t1.getText().toString();
                String pwd = t2.getText().toString();
                
                try {
                FileReader fr = new FileReader("login.txt");
                BufferedReader br = new BufferedReader(fr);
                String line;
                while((line=br.readLine())!=null){
                    if(line.equals(uname+"\t"+pwd)) {
                        matched = true;
                        break;
                    }
                }
                fr.close();
                }catch(Exception e){}
                
                if(matched) {
                    // Notify the login listener that the user has logged in
                    if (loginListener != null) {
                        loginListener.onLogin();
                    }
                    dispose();
                }
                else {
                    l2.setText("Invalid username or password");
                }
            }
        });
        
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SignUp s= new SignUp();
                s.setVisible(true);
                s.setBounds(200,200,500,300);
            }
        });
    }
    
    public void addLoginListener(LoginListener listener) {
        this.loginListener = listener;
    }
}


class LoginFrame extends JFrame {
    public static void main(String[] args) {
        Login loginFrame = new Login();
        loginFrame.setBounds(400,200,500,300);
        loginFrame.setVisible(true);
	}
}

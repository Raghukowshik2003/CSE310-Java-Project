package progJava;

public class GEnericMouse {
	public static void Leftclick() {
		System.out.println("leftclick");
	}
	public static void Rightclick() {
		System.out.println("right click");
	}
	public static void Scrollup() {
		System.out.println("Scrolled up");
	}
	public static  void Scrolldown() {
		System.out.println("Scrolled down");
	}
}

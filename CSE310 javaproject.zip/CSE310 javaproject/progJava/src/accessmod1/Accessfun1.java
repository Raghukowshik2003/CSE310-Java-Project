package accessmod1;

public class Accessfun1 {
	protected float marks=22.9f;
	protected String grade= "A+"; 
	float MARKS;
	
	protected float getMarks(){
		return marks;
	}

}

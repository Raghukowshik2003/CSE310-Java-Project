package accessmod1;

public class Accessfun2 {

	public static void main(String[] args) {
		Accessfun1 fun = new Accessfun1();
		System.out.println("Same package");
		System.out.println(fun.grade);
		System.out.println(fun.marks);
	}

}

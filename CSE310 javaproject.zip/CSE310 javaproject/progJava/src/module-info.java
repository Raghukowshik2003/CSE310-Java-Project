/**
 * 
 */
/**
 * @author Mohana
 *
 */
module progJava {
	requires java.desktop;
	requires java.sql;
}